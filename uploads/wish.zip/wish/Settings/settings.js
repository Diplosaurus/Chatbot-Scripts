﻿var settings = {
  "Command": "!wish",
  "Permission": "everyone",
  "Cooldown": 0,
  "InsufficientPointsResponse": "Insufficient points for requested wishes. Broke bitch.",
  "EventFiveStar": "Yae Miko (Electro)",
  "EventFourStars": "Diona (Cryo), Fischl (Electro), Thoma (Pyro)",
  "Cost": 160,
  "AdditionalFourStars": "",
  "MaxWishes": 10
};